const express = require('express');
const cors = require('cors');
const pool = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

// CREATE
app.post('/cars', async (req, res) => {
  const { brand, model, year } = req.body;
  try {
    const [result] = await pool.query('INSERT INTO cars (brand, model, year) VALUES (?, ?, ?)', [brand, model, year]);
    res.json({ id: result.insertId, brand, model, year });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// READ ALL
app.get('/cars', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM cars');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// READ ONE
app.get('/cars/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM cars WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Car not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE
app.put('/cars/:id', async (req, res) => {
  const { brand, model, year } = req.body;
  try {
    await pool.query('UPDATE cars SET brand = ?, model = ?, year = ? WHERE id = ?', [brand, model, year, req.params.id]);
    res.json({ message: 'Car updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE
app.delete('/cars/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM cars WHERE id = ?', [req.params.id]);
    res.json({ message: 'Car deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(3000, () => console.log('Server on port 3000'));
