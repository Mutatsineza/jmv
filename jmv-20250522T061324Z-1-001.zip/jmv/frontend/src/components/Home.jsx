import { useState } from 'react';
import AddCarForm from './AddCarForm';
import CarList from './CarList';

function Home() {
  const [activePage, setActivePage] = useState('add');

  const handleNavClick = (page) => {
    setActivePage(page);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-blue-600 text-white p-4 text-center text-2xl font-bold">
        Car Management App
      </header>

      <div className="flex flex-1">
        {/* Aside navigation */}
        <aside className="w-48 bg-gray-200 p-4">
          <nav className="space-y-4">
            <button
              onClick={() => handleNavClick('add')}
              className={`block w-full text-left px-3 py-2 rounded ${
                activePage === 'add' ? 'bg-blue-600 text-white' : 'hover:bg-blue-300'
              }`}
            >
              Add Car
            </button>
            <button
              onClick={() => handleNavClick('view')}
              className={`block w-full text-left px-3 py-2 rounded ${
                activePage === 'view' ? 'bg-blue-600 text-white' : 'hover:bg-blue-300'
              }`}
            >
              View Cars
            </button>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 bg-white p-6 overflow-auto">
          {activePage === 'add' && <AddCarForm onCarAdded={() => setActivePage('view')} />}
          {activePage === 'view' && <CarList />}
        </main>
      </div>
    </div>
  );
}

export default Home;
