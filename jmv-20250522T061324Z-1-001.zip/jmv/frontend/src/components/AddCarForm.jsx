import { useState } from 'react';
import axios from 'axios';

function AddCarForm({ onCarAdded }) {
  const [form, setForm] = useState({ brand: '', model: '', year: '' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:3000/cars', form);
      setForm({ brand: '', model: '', year: '' });
      if (onCarAdded) onCarAdded();
    } catch (err) {
      console.error('Error adding car:', err);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4">
      <input
        type="text"
        name="brand"
        value={form.brand}
        onChange={handleChange}
        placeholder="Brand"
        className="w-full px-4 py-2 border rounded-md"
        required
      />
      <input
        type="text"
        name="model"
        value={form.model}
        onChange={handleChange}
        placeholder="Model"
        className="w-full px-4 py-2 border rounded-md"
        required
      />
      <input
        type="number"
        name="year"
        value={form.year}
        onChange={handleChange}
        placeholder="Year"
        className="w-full px-4 py-2 border rounded-md"
        required
      />
      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition"
      >
        Add Car
      </button>
    </form>
  );
}

export default AddCarForm;
