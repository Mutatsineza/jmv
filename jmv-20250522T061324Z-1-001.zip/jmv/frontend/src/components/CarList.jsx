import { useState, useEffect } from 'react';
import axios from 'axios';

function CarList() {
  const [cars, setCars] = useState([]);
  const [editingCarId, setEditingCarId] = useState(null);
  const [editForm, setEditForm] = useState({ brand: '', model: '', year: '' });

  useEffect(() => {
    loadCars();
  }, []);

  const loadCars = async () => {
    try {
      const res = await axios.get('http://localhost:3000/cars');
      setCars(res.data);
    } catch (err) {
      console.error('Error loading cars:', err);
    }
  };

  const startEditing = (car) => {
    setEditingCarId(car.id);
    setEditForm({ brand: car.brand, model: car.model, year: car.year });
  };

  const handleEditChange = (e) => {
    setEditForm({ ...editForm, [e.target.name]: e.target.value });
  };

  const cancelEditing = () => {
    setEditingCarId(null);
    setEditForm({ brand: '', model: '', year: '' });
  };

  const submitEdit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:3000/cars/${editingCarId}`, editForm);
      setEditingCarId(null);
      setEditForm({ brand: '', model: '', year: '' });
      loadCars();
    } catch (err) {
      console.error('Error updating car:', err);
    }
  };

  const deleteCar = async (id) => {
    try {
      await axios.delete(`http://localhost:3000/cars/${id}`);
      loadCars();
    } catch (err) {
      console.error('Error deleting car:', err);
    }
  };

  return (
    <ul className="mt-6 space-y-3 p-4">
      {cars.map((car) => (
        <li
          key={car.id}
          className="flex justify-between items-center bg-gray-50 px-4 py-2 rounded shadow-sm"
        >
          {editingCarId === car.id ? (
            <form onSubmit={submitEdit} className="flex space-x-2 w-full items-center">
              <input
                type="text"
                name="brand"
                value={editForm.brand}
                onChange={handleEditChange}
                className="flex-1 px-2 py-1 border rounded-md"
                placeholder="Brand"
                required
              />
              <input
                type="text"
                name="model"
                value={editForm.model}
                onChange={handleEditChange}
                className="flex-1 px-2 py-1 border rounded-md"
                placeholder="Model"
                required
              />
              <input
                type="number"
                name="year"
                value={editForm.year}
                onChange={handleEditChange}
                className="w-20 px-2 py-1 border rounded-md"
                placeholder="Year"
                required
              />
              <button
                type="submit"
                className="bg-green-600 text-white px-3 py-1 rounded-md hover:bg-green-700 transition"
              >
                Save
              </button>
              <button
                type="button"
                onClick={cancelEditing}
                className="bg-gray-400 text-white px-3 py-1 rounded-md hover:bg-gray-500 transition"
              >
                Cancel
              </button>
            </form>
          ) : (
            <>
              <span>{car.brand} - {car.model} ({car.year})</span>
              <div className="flex space-x-2">
                <button
                  onClick={() => startEditing(car)}
                  className="text-blue-500 hover:text-blue-700"
                >
                  Edit
                </button>
                <button
                  onClick={() => deleteCar(car.id)}
                  className="text-red-500 hover:text-red-700"
                >
                  Delete
                </button>
              </div>
            </>
          )}
        </li>
      ))}
    </ul>
  );
}

export default CarList;
